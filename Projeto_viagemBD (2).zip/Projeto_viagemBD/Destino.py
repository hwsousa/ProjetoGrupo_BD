from colorama import Fore, Back, Style
import sqlite3
conexao = sqlite3.connect('viagens.db')
cursor = conexao.cursor()
cursor.execute(
    'CREATE TABLE IF NOT EXISTS Destinos('
    'IdDestino INTEGER PRIMARY KEY,'
    'NomeDestino TEXT,'
    'Descricao TEXT,'
    'AtracoesPrincipais TEXT,'
    'Localizacao TEXT)'
)

conexao.commit()

def exibir_menu():

    while True:
        print( "           DESTINOS DE VIAGEM ")
        print("\n=================  MENU  ================")
        print("| 1. Inserir novo Destino               |")
        print("| 2. Exibir informações do Destino      |")
        print("| 3. Editar informações do Destino      |")
        print("| 4. Excluir Destino                    |")
        print("| 5. Sair                               |")
        print("=========================================")
        opcao = int(input("\nDigite o número da opção desejada: "))
        if opcao == 1:
            inserir_destino()
        elif opcao == 2:
            exibir_destino()
        elif opcao == 3:
            alterar_destino()
        elif opcao == 4:
            excluir_destino()
        elif opcao == 5:
            conexao.close()
            break
        else:
            print(Fore.RED + "Opção inválida. Por favor, escolha uma opção válida.")

def inserir_destino():
    idDestino = int(input('Digite o numero de id do seu destino:'))
    nomeDestino = str(input('Digite o nome do destino: '))
    descricao = str(input('Uma descrição do seu destino: '))
    atracoesPrincipais = str(input('Atrações principais: '))
    localizacao = str(input('Localização do destino: '))

    cursor.execute('INSERT INTO Destinos'
                   '(IdDestino, NomeDestino, Descricao, AtracoesPrincipais, Localizacao)'
                   'VALUES (?,?,?,?,?);',
                   (idDestino, nomeDestino,descricao,atracoesPrincipais,localizacao))
    conexao.commit()

def exibir_destino():
    IdDestino = int(input('Digite o numero de id do seu destino:'))
    cursor.execute('SELECT * FROM Destinos WHERE idDestino =?', (IdDestino,))
    dados_de_viagem = cursor.fetchone()
    print('Informações da sua viagem ⛩ ')
    print('IdDestino:', dados_de_viagem[0])
    print('NomeDestino:', dados_de_viagem[1])
    print('Descricao:', dados_de_viagem[2])
    print('AtracoesPrincipais:', dados_de_viagem[3])
    print('Localizacao:', dados_de_viagem[4])

def alterar_destino():
    IdDestino = int(input('Digite o ID de viagem que deseja alterar: '))
    cursor.execute('SELECT * FROM Destinos WHERE idDestino =?', (IdDestino,))
    dados_de_viagem = cursor.fetchone()
    print('Informações da sua viagem 🗽 ')
    print('IdDestino:', dados_de_viagem[0])
    print('NomeDestino:', dados_de_viagem[1])
    print('Descricao:', dados_de_viagem[2])
    print('AtracoesPrincipais:', dados_de_viagem[3])
    print('Localizacao:', dados_de_viagem[4])
    campo = str(input('Digite o nome do campo que deseja alterar: '))
    novo_valor = str(input(f'Digite o novo valor do campo {campo}:'))
    cursor.execute(f'UPUDATE Destinos SET {campo} = ? WHERE IdDestino = ?',
                   (novo_valor, IdDestino))
    conexao.commit()

def excluir_destino():
    Excluido = int(input('Digite o ID de viagem que deseja excluir: '))
    cursor.execute('DELETE FROM Destinos WHERE idDestino =?', (Excluido,))
    conexao.commit()
