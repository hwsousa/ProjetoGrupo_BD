import sqlite3
conexao = sqlite3.connect('viagens.db')
cursor = conexao.cursor()
cursor.execute('CREATE TABLE IF NOT EXISTS Pacote('
    'IDPacote INTEGER PRIMARY KEY, '
    'NomePacote TEXT,'
    'Destino INTEGER,'
    'Descrição TEXT,'
    'Preço TEXT)'
    )

def exibir_menu():
    print("===💸 Pacotes 💸===")
    while True:
        print("\n=================  MENU  ================")
        print("| 1. Inserir novo pacote             |")
        print("| 2. Exibir informações de um pacote |")
        print("| 3. Editar informações de um pacote |")
        print("| 4. Excluir pacote                  |")
        print("| 5. Voltar                          |")
        print("=========================================")
        opcao = int(input("\nDigite o número da opção desejada: "))
        if opcao == 1:
            inserir_pacotes()
        elif opcao == 2:
            exibir_pacote()
        elif opcao == 3:
            alterar_pacote()
        elif opcao == 4:
            excluir_pacote()
        elif opcao == 5:
            conexao.close()
            break
        else:
            print("Opção inválida. Por favor, escolha uma opção válida.")


def inserir_pacotes():
    IDPacote = int(input('Digite o ID para o pacote: '))
    NomePacote = str(input('Digite o nome do pacote: '))
    Destino = str(input('Digite o Destino desse pacote: '))
    Descrição = str(input('Digite uma descrição para esse pacote: '))
    Preço = float(input('Digite um preço para esse pacote: '))

    cursor.execute('INSERT INTO Pacote'
                    '(IDPacote,NomePacote,Destino,Descrição,Preço) '
                   ' VALUES (?,?,?,?,?);',
                    (IDPacote,NomePacote, Destino, Descrição,Preço))
    conexao.commit()

def exibir_pacote():
    ID_Pacote = int(input('Digite o ID: '))
    cursor.execute ('SELECT * FROM Pacote WHERE IDPacote = ?', (ID_Pacote,))
    dados_pacotes = cursor.fetchone()

    print('==========Informações do pacote==========')
    print('Nome do pacote:',dados_pacotes[0])
    print('Destino do pacote: ',dados_pacotes[1])
    print('Descrição do pacote: ',dados_pacotes[2])
    print('Preço do pacote: ',dados_pacotes[3])
    print('=========================================')

def alterar_pacote():
    ID_Pacote = int(input('Digite o ID do pacote que deseja: '))
    cursor.execute('SELECT * FROM Pacote WHERE IDPacote = ?', (ID_Pacote,))
    dados_pacotes = cursor.fetchone()
    print('informações do pacote: ')
    print('ID: ', dados_pacotes[0])
    print('Nome: ', dados_pacotes[1])
    print('Data de nascimento: ', dados_pacotes[2])
    print('Genero: ', dados_pacotes[3])

    campo = str(input('Digite o nome do campo que deseja alterar: '))
    novo_valor = str(input(f"Digite o novo valor para o campo '{campo}': "))
    cursor.execute(f'UPDATE Pacote SET {campo} = ? WHERE IDPacote = ?;',
                    (novo_valor, ID_Pacote))
    conexao.commit()

def excluir_pacote():
    excluido = int(input('Digite o ID do pacote que deseja excluir: '))
    cursor.execute('DELETE FROM Pacote WHERE IDPacote =?', (excluido,))
    conexao.commit()


