import Destino #laura
import Pacote #biazoto
import Reserva #lorena
import Reservas #nalice


def Menu():
    while True:
        print("\n===========🗽  MENU DE VIAGENS 🗽 ===========")
        print("| 1. Destinos                         |")
        print("| 2. Pacotes Turísticos               |")
        print("| 3. Reservas de Hotel                |")
        print("| 4. Reservas de Transporte           |")
        print("| 5. Sair                             |")
        print("=========================================")
        opcaoprincipal = int(input("\nDigite o número da opção desejada: "))
        if opcaoprincipal == 1:
            Destino.exibir_menu()
        elif opcaoprincipal == 2:
            Pacote.exibir_menu()
        elif opcaoprincipal == 3:
            Reserva.exibir_menu()
        elif opcaoprincipal == 4:
            Reservas.exibir_menu()
        elif opcaoprincipal == 5:
            print("Obrigado por usar nossa plataforma")
            print("Saindo...")
            break
        else:
            print("Opção não encontrada tente novamente")
Menu()