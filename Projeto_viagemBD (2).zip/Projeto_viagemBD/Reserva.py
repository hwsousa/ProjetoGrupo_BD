import sqlite3

conexao = sqlite3.connect('viagens.db')

cursor = conexao.cursor()

cursor.execute('CREATE TABLE IF NOT EXISTS Reservas ('
               'IDReserva INTEGER PRIMARY KEY,'
               'Pacote TEXT ,'
               'Hotel TEXT,'
               'DataEntrada TEXT,'
               'DataSaída TEXT,'
               'NumeroQuartos INTEGER)'
                )

def Inserir_Reservas():
    idreserva =int(input('Digite o REGISTRO DE RESERVA: '))
    pacote = input('Digite o NOME DO PACOTE: ')
    hotel = str(input("Digite o NOME DO HOTEL: "))
    dataEntr = input("Digite a DATA DE ENTRADA:  ")
    dataSaid = input("Digite a DATA DE SAIDA: ")
    numquartos = int(input("Digite o NUMERO DE QUARTOS: "))
    status_reserva = input("Digite o STATUS DA RESERVA (confirmada, pendente, cancelada, completada): ")
    servicos_adicionais = input("Digite os SERVIÇOS ADICIONAIS (separados por vírgula se houver mais de um): ")

    cursor.execute('INSERT INTO Reservas'
                   '(IDReserva, Pacote, Hotel, DataEntrada, DataSaída, NumeroQuartos,StatusReserva,ServicosAdicionais)'
                   'VALUES (?,?,?,?,?,?,?,?);',
                   (idreserva, pacote, hotel, dataEntr, dataSaid, numquartos,status_reserva,servicos_adicionais))
    conexao.commit()  # salva as alterações no banco

def Exibir_Reservas():
    id_reserva = int(input('Digite o  ID DA RESERVA: '))
    cursor.execute('SELECT * FROM Reservas WHERE IDReserva =?;', (id_reserva,))
    dados_cliente = cursor.fetchone()

    if not dados_cliente:
        print("Reserva não encontrada.")
        return

    id_reserva, pacote, hotel, data_entrada, data_saida, num_quartos, status_reserva, servicos_adicionais = dados_cliente

    print(f'RESERVA NÚMERO 🏨 {id_reserva} 🏨:')
    print("=======📜Informações📜======")
    print("ID:", dados_cliente[0])
    print("PACOTE:", dados_cliente [1])
    print("HOTEL:", dados_cliente[2])
    print("DATA DE ENTRADA:", dados_cliente[3])
    print("DATA DE SAÍDA:", dados_cliente[4])
    print("NÚMERO DE QUARTOS:", dados_cliente[5])
    print("STATUS DA RESERVA:", end=' ')

    if status_reserva == 'confirmada':
        print("✔")
    elif status_reserva == 'pendente':
        print("🟡")
    elif status_reserva == 'cancelada':
        print("❌")
    elif status_reserva == 'completada':
        print("✅")
    else:
        print(status_reserva)

    print("SERVIÇOS ADICIONAIS:", servicos_adicionais)


def Alterar_Reservas():
    id_reserva = int(input("Digite o ID DA RESERVA: "))
    campo = str(input("Digite o nome do campo que deseja alterar: "))
    novo_valor = str(input(f"Digite o novo valor para o campo '{campo}': "))
    cursor.execute(f'UPDATE Reservas SET {campo} = ? WHERE IDReserva = ?;',
                   (novo_valor, id_reserva))
    cursor.execute('SELECT * FROM Estudantes WHERE RM =?;', (id_reserva,))
    dados_cliente = cursor.fetchone()
    print(f'RESERVA NÚMERO  {id_reserva} :')
    print("=======Informações======")
    print("ID:", dados_cliente[0])
    print("PACOTE:", dados_cliente[1])
    print("HOTEL:", dados_cliente[2])
    print("DATA DE ENTRADA:", dados_cliente[3])
    print("DATA DE SAÍDA:", dados_cliente[4])
    print("NÚMERO DE QUARTOS:", dados_cliente[5])
    print("STATUS DA RESERVA:", dados_cliente[6])
    print("SERVIÇOS ADICIONAIS: ", dados_cliente[7])
    conexao.commit()

def Excluir_Reserva():
    Excluido = int(input('Digite o ID DA RESERVA: '))
    cursor.execute('DELETE FROM Reservas WHERE IDReserva= ?', (Excluido,))
    conexao.commit()


def exibir_menu():
        print("🏨 RESERVAS 🏨")
        while True:
            print("\n=================  MENU  ================")
            print("| 1. Fazer nova Reserva                |")
            print("| 2. Exibir informações de Reserva     |")
            print("| 3. Editar informações de uma Reserva |")
            print("| 4. Apagar Reserva                    |")
            print("| 5. Sair                             |")

            opcao = int(input("\nDigite o número da opção desejada: "))
            if opcao == 1:
                Inserir_Reservas()
            elif opcao == 2:
                Exibir_Reservas()
            elif opcao == 3:
                Alterar_Reservas()
            elif opcao == 4:
                Excluir_Reserva()
            elif opcao == 5:
                conexao.close()
                break
            else:
                print("Opção inválida. Por favor, escolha uma opção válida.")
