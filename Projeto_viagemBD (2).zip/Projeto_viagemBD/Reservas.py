import sqlite3

conexao = sqlite3.connect('viagens.db')
cursor = conexao.cursor()
cursor.execute(
    'CREATE TABLE IF NOT EXISTS Reservas('
    'ID INTEGER PRIMARY KEY,'
    'Pacote TEXT,'
    'MeioDeTransporte TEXT,'
    'Data DATE,'
    'NumerosDePassageiros INTEGER)')

# MENU----------------------------
def exibir_menu():
    print(" Reservas 🌐 ")
    while True:
        print("===============  MENU  ================")
        print("| 1. Inserir nova reserva              |")
        print("| 2. Exibir informações de uma reserva |")
        print("| 3. Editar informações de uma reserva |")
        print("| 4. Excluir reserva                   |")
        print("| 5. Sair                              |")
        print("=========================================")
        opcao = int(input("\nDigite o número da opção desejada: "))
        if opcao == 1:
            inserir_reservas()
        elif opcao == 2:
            exibir_reservas()
        elif opcao == 3:
            alterar_reservas()
        elif opcao == 4:
            excluir_reservas()
        elif opcao == 5:
            print('Obrigado por usar nossa agência 🌎')
            print('Bye Bye....')
            break
        else:
            print("\nOpção inválida. Por favor, escolha uma opção válida.")

#INSERIR-------------------------
def inserir_reservas():
    id = int(input('\nDigite o ID da reserva:'))
    pacote = str(input('Digite o pacote da reserva:'))
    meio_de_transporte = str(input('Insira o meio de transporte:'))
    data = str(input('Insira o data da reserva:'))
    numero_de_passageiros = int(input('Insira o numero de passageiros:'))

    cursor.execute('INSERT INTO Reservas '
                   '(ID, Pacote, MeioDeTransporte, Data, NumerosDePassageiros) '
                   'VALUES (?, ?, ?, ?, ?);',
                   (id, pacote, meio_de_transporte, data, numero_de_passageiros))
    print('\nInformações inseridas !')
    conexao.commit()

#EXIBIR-----------------------------
def exibir_reservas():
    id_reservas = int(input('\nDigite o ID da reserva:'))
    cursor.execute('SELECT * FROM Reservas WHERE ID = ?;', (id_reservas,))
    dados_reservas = cursor.fetchone()
    print('Informações da reserva ⬇⬇')
    print('ID:', dados_reservas[0])
    print('Pacote:', dados_reservas[1])
    print('Meio de Transporte:', dados_reservas[2])
    print('Data da reserva:', dados_reservas[3])
    print('Número de passageiros:', dados_reservas[4])

#ALTERAR-----------------------
def alterar_reservas():
    id_reservas = int(input("\nDigite o ID da reserva: "))
    cursor.execute('SELECT * FROM Reservas WHERE ID = ?;', (id_reservas,))
    dados_reservas = cursor.fetchone()
    print('Informações da reserva ⬇⬇ ')
    print('ID:', dados_reservas[0])
    print('Pacote:', dados_reservas[1])
    print('Meio de Transporte:', dados_reservas[2])
    print('Data da reserva:', dados_reservas[3])
    print('Número de passageiros:', dados_reservas[4])
    campo = str(input("Digite o nome do campo que deseja alterar: "))
    novo_valor = str(input(f"Digite o novo valor para o campo {campo}:"))
    cursor.execute(f'UPDATE Reservas SET {campo} = ? WHERE ID = ?;',
                  (novo_valor, id_reservas))
    print('\nEditado com sucesso!')
    conexao.commit()

# EXCLUIR----------------------------
def excluir_reservas():
    Excluido = int(input('\nDigite o ID da reserva que deseja excluir:'))
    cursor.execute('DELETE FROM Reservas WHERE ID = ?;',(Excluido,))
    print('\nReserva excluída com sucesso!')
    conexao.commit()
